﻿namespace WildFarm.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public static class InvalidTypeOfFood
    {
        public  static string invalidFoodType = "{0} does not eat {1}!";
    }
}
