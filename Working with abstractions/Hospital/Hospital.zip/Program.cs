﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Hospital
{
    public class Program
    {
        static void Main()
        {
            var engine = new Engine();
            Engine.StartUp();
        }

    }
}

