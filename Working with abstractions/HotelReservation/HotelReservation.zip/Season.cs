﻿using System;
using System.Collections.Generic;
using System.Text;

public enum SeasonMultiplier
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
}