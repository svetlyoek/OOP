﻿using System;
using System.Collections.Generic;
using System.Text;

public enum DiscountPercentage
{
    None,
    SecondVisit = 10,
    VIP = 20
}