﻿using System;
using System.Linq;

namespace JediGalaxy
{
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.StartUp();
        }
    }
}
