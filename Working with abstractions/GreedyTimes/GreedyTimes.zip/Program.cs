﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GreedyTimes
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}