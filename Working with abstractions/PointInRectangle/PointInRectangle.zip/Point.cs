﻿namespace PointInRectangle
{
    public class Point
    {

        public Point(double coordinateX, double coordinateY)
        {
            this.CoordinateX = coordinateX;
            this.CoordinateY = coordinateY;
        }
        public double CoordinateX { get; set; }

        public double CoordinateY { get; set; }
    }
}
