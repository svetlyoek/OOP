﻿using System;

namespace Sneaking
{
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();

        }

    }
}
