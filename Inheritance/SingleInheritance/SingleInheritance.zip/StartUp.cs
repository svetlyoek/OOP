﻿using System;

namespace Farm
{
    public class StartUp
    {
        public static void Main()
        {
            var dog = new Dog();
            dog.Bark();
            dog.Eat();
        }
    }
}
