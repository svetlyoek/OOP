﻿using System;

namespace Farm
{
  public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
