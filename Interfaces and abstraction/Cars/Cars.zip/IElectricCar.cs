﻿namespace Cars
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public interface IElectricCar
    {
        int Battery { get; }
    }
}
