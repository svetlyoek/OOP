﻿namespace PersonInfo
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public static class ExceptionMessages
    {
        public static string invaliName = "Name cannot be null or empty!";

        public static string invalidAge = "Age cannot be negative!";
    }
}
