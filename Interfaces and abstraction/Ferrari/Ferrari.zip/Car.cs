﻿namespace Ferrari
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Car
    {
        public string PushBrakes()
        {
            return $"Brakes!";
        }

        public string PushGas()
        {
            return $"Gas!";
        }
    }
}
