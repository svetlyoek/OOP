﻿namespace Telephony
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public static class ExceptionMessages
    {
        public static string invalidNumber = "Invalid number!";

        public static string invalidUrl = "Invalid URL!";
    }
}
