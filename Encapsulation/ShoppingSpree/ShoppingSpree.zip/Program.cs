﻿namespace ShoppingSpree
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }

    }
}
