using NUnit.Framework;
using System;

namespace Tests
{
    [TestFixture]
    public class DatabaseTests
    {
        private Database dataBase;

        [SetUp]
        public void Setup()
        {
            int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            this.dataBase = new Database(numbers);
        }

        [Test]
        public void ConstructorTest()
        {
            Assert.AreEqual(16, this.dataBase.Count);
        }

        [Test]
        public void AddExceptionTest()
        {
            Assert.Throws<InvalidOperationException>(() => this.dataBase.Add(17));
        }

        [Test]
        public void AddTest()
        {
            this.dataBase = new Database(1, 2, 3, 4);

            this.dataBase.Add(5);

            Assert.AreEqual(5, this.dataBase.Count);
        }

        [Test]
        public void RemoveExceptionTest()
        {
            this.dataBase = new Database();

            Assert.Throws<InvalidOperationException>(() => this.dataBase.Remove());
        }

        [Test]
        public void RemoveTest()
        {
            this.dataBase.Remove();

            Assert.AreEqual(15, this.dataBase.Count);
        }

        [Test]
        public void FetchTest()
        {
            Assert.AreEqual(16, this.dataBase.Fetch().Length);
        }

    }
}